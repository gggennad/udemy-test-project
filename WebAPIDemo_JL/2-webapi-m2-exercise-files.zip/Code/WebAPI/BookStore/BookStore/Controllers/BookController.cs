﻿using System.Web.Http;

namespace BookStore.Controllers
{
    public class BookController : ApiController
    { }
}